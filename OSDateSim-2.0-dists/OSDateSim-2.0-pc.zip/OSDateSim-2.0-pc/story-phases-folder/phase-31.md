# Fase 31

## Programas executando ao mesmo tempo

Fase 31 – Como controlar o compartilhamento de recursos (sem deixar pros usuários)

"Precisamos centralizar esse controle. Nada de deixar os processos decidirem."

tablet: "O sistema operacional define quando e como cada processo pode usar o recurso."

jorge: "Então você vai controlar o novo cara?"

tablet: "Já estou criando uma tabela de permissões."

personagem_estrangeiro: balança a cabeça confuso

Fase 38 – O que é um Driver?

tablet: "Driver é um software intermediário entre o sistema operacional e o hardware."

"Tipo... um intérprete?"

tablet: "Exatamente. Ele traduz os comandos do SO para o periférico e vice-versa."

personagem_estrangeiro: “Driver!”
jorge: "Olha só! Ele entendeu!"

tablet: "Baixando pacote de idioma... Driver de comunicação iniciado."

"Agora sim, podemos falar com ele... Ou pelo menos tentar."

