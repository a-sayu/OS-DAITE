# Fase 22

## Como controlar esse compartilhamento sem que os processos de usuários sejam responsáveis, como seria o controle

Fase 22 – Controle de recursos pelo sistema operacional

"Então, ao invés da gente decidir por conta própria, vamos fazer o tablet definir os turnos."

tablet: "Serei o escalonador de motoristas?"

"Sim. Você decide de forma justa, sem brigas, nem ego."

jorge: "Desde que eu possa argumentar..."
