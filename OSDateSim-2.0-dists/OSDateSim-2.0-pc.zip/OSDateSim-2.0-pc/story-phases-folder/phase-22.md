# Fase 22

## Como controlar esse compartilhamento sem que os processos de usuários sejam responsáveis, como seria o controle
