# Fase 5

## Tema: qual a relação entre so, programas de usuário e escalonamento?

"Okay, então como eu deveria escalonar me alimentar, me proteger e procurar por minha irmã?"

"Tipo, eu posso comer enquanto procuro minha irmã e fico atento para qualquer perigo a minha volta..."

computer "Bem, você não precisa estar fazendo tudo ao mesmo tempo, isso não é escalonar!"

computer "Devemos pensar sobre isso com muito cuidado."

"Realmente... Já que estamos pensando em conceitos de Sistemas Operacionais, que tal relacionar essas coisas como programas?"

computer "Então... Quando você precisa se alimentar?"

1- "Eu posso comer quando eu puder, não é tão necessário..." // FDP

2- "Eu tenho que separar pelo menos algum tempo para encontrar mais alimentos e comer." // VDD

"Então... Quando você precisa se proteger?"

1- "Está muito perigoso, eu deveria colocar toda minha atenção para isso..." // FDP

2- "É importante estar atento... Mas descansar também, eu posso sempre procurar abrigos." //VDD

"Então... Quando você precisa buscar sua irmã?"

1- "Eu deveria focar nessa busca totalmente... Se eu demorar como vou ter certeza que ela estará a salvo..."

2- "Mesmo que eu não saiba onde minha irmã está, eu também não posso deixar de me cuidar..."

Caso: Todas as respostas corretas.

computer "Exatamente, uma divisão de tempo para cada ação é importante, não foque demais em algo e agende seus programas, isso é escalonar os programas!"

Caso: Alguma errada.

Primeira - computer "Comida é importante, mas não se deve ficar comendo também não é tão bom..."

Segunda - computer "Segurança é importante, mas não se deve viver paranóico..."

Terceira - computer "Buscar sua irmã é importante, mas não se deve ignorar suas necessidades..."
