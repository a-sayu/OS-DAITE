# Fase 21

## O problema de processos serem responsáveis pelo controle de recursos

Fase 21 – Problema: processos controlando recursos

Enquanto dirigem...

jorge: "Se só eu decidir quando parar, posso abusar do volante..."

"Exatamente. Processos decidindo tudo por si só causam conflitos."

tablet: "É por isso que o SO deve controlar o compartilhamento. Pra evitar deadlocks."

jorge: "Você me chamou de deadlock?"

"Não... Mas quase."
