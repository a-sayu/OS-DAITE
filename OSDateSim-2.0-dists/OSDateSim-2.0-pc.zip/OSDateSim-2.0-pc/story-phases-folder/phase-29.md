# Fase 29

## Atomicidade

Fase 29 – Compartilhamento de recursos entre processos (continuação)

Enquanto tentam se comunicar com o novo personagem...

tablet: "Enquanto não entendo ele, quem cuida do carro?"

"Turno do Jorge. Eu cuido do novo processo."

jorge: "Tá, mas se ele for maluco?"

tablet: "Alternância de contexto: você vigia. Ele é novo, pode ser processo zumbi."

"Vamos torcer pra ser só um bug leve."

Fase 36 – Como o SO lida com interrupções: rotina de tratamento

Todos olham em direção ao barulho distante.

jorge: "Isso foi perto... e alto."

tablet: "Executando rotina de tratamento de interrupção..."

"Então o SO precisa pausar o que estava fazendo, lidar com o problema e só depois retomar, certo?"

tablet: "Exato. Salvo o contexto atual, trato o evento externo e, quando for seguro, continuo de onde paramos."

jorge: "Tipo parar de cozinhar porque a campainha tocou?"

tablet: "Exemplo aceitável."

