# Fase 8

## Tema: A relação do so, programas do usuário e os processos

Você então pega o tablet e o observa, também coletando o carregador do tablet.

Você então se senta na cadeira novamente e apoia sobre a mesa, admirando o tablet que arduamente tinha conseguido.

"Por quê? Por que tanta segurança pra algo tão simples?"

Você olha para o computador, que marcava pouco mais de 95%.

'Qual a relação entre tudo que eu fiz com a necessidade de tantas etapas?'

Refletindo, você pensa em cada passo que você concluiu para recuperar o tablet.

Primeiro o caderno, depois onde estava sendo armazenado o tablet.

Depois encontrar a senha...

'Espera, a senha era sobre sistemas operacionais, sobre processos, talvez o que eu fiz tenha a ver com isso pois...'

1 - Em um sistema operacional, assim como esse escritório, ele contém informações necessárias para que um programa, no caso abrir um cofre sejam executados com sucesso //vdd
2 - Em um sistema operacional, cada programa é como uma pista, só quando se tem todas se abre o cofre, no caso o processo se inicia. //fdp
3 - Em um sistema operacional, um processo é um conjunto de instruções, e para abrir esse cofre foi seguido um conjunto de intruções. //fdp

Caso 1:
    "E isso é um processo."
    "Porque um processo é um programa e o conjunto de informações necessárias para que ele seja executado."
    "To ficando craque em Sistemas Operacionais ein..."

Caso 2:
    "Não... Não é bem isso."
    "As pistas são informações necessárias para o programa."
    "Mas elas não são o programa, elas apenas fazer parte do processo."
    "Portanto, o processo já havia começado quando as pistas foram encontradas."

Caso 3:
    "Não... Não é bem isso."
    "Um conjunto de instruções pode ser a definição de programa."
    "Mas não de processo."
    "Apesar de necessárias para o real programa que era abrir o cofre."
    "Algumas informações não fazem parte do programa, mas sim do sistema operacional."
