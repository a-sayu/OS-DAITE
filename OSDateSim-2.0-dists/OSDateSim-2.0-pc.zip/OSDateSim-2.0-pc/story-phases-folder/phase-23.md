# Fase 23

## Quando ocorre a chamada do sistema durante a execução do sistema operacional

Fase 23 – Quando ocorre a chamada de sistema

jorge: "Ei, tablet! Liga o rádio aí!"

tablet: "Isso é uma chamada de sistema. Um pedido de recurso externo."

"É... tipo quando um processo pede pra usar a impressora. Só que nesse caso... o rádio."

jorge: "E se ele não funcionar?"

tablet: "Erro de chamada de sistema. 404: vibes not found."
