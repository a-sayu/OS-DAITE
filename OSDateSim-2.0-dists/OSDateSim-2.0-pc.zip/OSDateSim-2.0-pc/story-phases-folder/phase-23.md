# Fase 23

## Quando ocorre a chamada do sistema durante a execução do sistema operacional
