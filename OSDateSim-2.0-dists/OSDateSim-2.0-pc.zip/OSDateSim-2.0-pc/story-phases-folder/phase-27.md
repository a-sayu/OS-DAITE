# Fase 27

## Um sistema operacional já é comercializado pronto para lidar com periféricos diversos? É necessário instalar algo?

Fase 27 – SOs já vêm preparados para periféricos?

Durante a limpeza da estrada, um novo personagem se aproxima. Ele fala... algo incompreensível.

personagem: "Dovahkiin nax von uldor?"

jorge: "Hã?"

tablet: "Esse periférico humano não é compatível com o idioma atual."

"Você tem suporte pra outros idiomas?"

tablet: "Nem sempre. Preciso instalar um driver de linguagem."
