# Fase 27

## Um sistema operacional já é comercializado pronto para lidar com periféricos diversos? É necessário instalar algo?
