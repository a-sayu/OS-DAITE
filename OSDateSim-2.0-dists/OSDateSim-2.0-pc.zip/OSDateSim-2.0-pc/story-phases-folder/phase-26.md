# Fase 26

## Como o sistema operacional lida com interrupções, o que é rotina de tratamento de interrupção
