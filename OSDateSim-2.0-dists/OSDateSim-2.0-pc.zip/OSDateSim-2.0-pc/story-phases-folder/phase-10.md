# Fase 10

## Qual a importância de armazenar o sistema operacional na memória RAM

Na tela de {computer} aparece um símbolo de carregamento.

"Você está pensando? Pensando em quê?"

computer "Pensando em por que você precisaria me colocar em uma memória primária."

computer "Mesmo que seja mais rápido, você estaria carregando mais peso, e seria mais prático só ter uma unica mochila."

1 - "Sim, mas conveniencia, sei lá?"

2 - "Sim, demora mais para acessar a mochila, mas minha busca é mais rápida se estiver ao alcance das minhas mãos."

Caso 1:

computer "Se for só por isso, não é melhor manter o que estava antes?"

"Mas, demoraria para buscar."

computer "Então explique melhor como isso importa."

Caso 2:

computer "Realmente, a busca é uma operação principal."

 "Se ela for lenta, como que eu poderia responder imediatamente?"

computer "Agora só falta qual vai ser a sua memória primária, então."
