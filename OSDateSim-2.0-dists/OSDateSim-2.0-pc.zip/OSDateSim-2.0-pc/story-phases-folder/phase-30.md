# Fase 30

## Ciclo de Vida dos Processos

Fase 30 – Problema: processos controlarem os recursos

personagem_estrangeiro: “Nax falderm kru!”
jorge: "Eu não confio nesse cara..."

tablet: "Processo tentando acessar recursos sem permissão. Isso é perigoso."

"É como se um programa tentasse controlar o disco rígido por conta própria."

tablet: "Sem SO no meio, isso vira caos."

jorge: "Ou vírus."

Fase 37 – Sistemas vêm prontos para lidar com periféricos?

O personagem estrangeiro mostra um aparelho com tela azul e fala algo animado.

personagem_estrangeiro: "Zinkara mod. Conectar."

tablet: "Dispositivo conectado... mas não reconhecido. Falta driver."

jorge: "Sério? Achei que o SO já vinha com tudo."

tablet: "Nem sempre. Dispositivos novos, periféricos não-padrão... precisam de drivers específicos."

"Ou seja, sem o driver, o SO não sabe como interagir com o aparelho."

tablet: "Correto. É como tentar conversar com um animal sem saber o idioma dele."

jorge: "Eu chamo isso de sexta-feira."

