# Fase 34

## Quantos vetores de interrupção são necessários?
