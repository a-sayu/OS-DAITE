# Fase 34

## Quantos vetores de interrupção são necessários?

Fase 34 – O que é uma interrupção, com exemplo

Um barulho de explosão ecoa ao longe. O grupo para imediatamente.

tablet: "Interrupção detectada: ruído alto e anormal. Entrada externa inesperada."

jorge: "Acho que alguém explodiu alguma coisa."

"Então agora é prioridade máxima... Temos que tratar essa interrupção antes de continuar."

tablet: "Preparando rotina de tratamento..."

Fase 43 – Programas executando “ao mesmo tempo”

Ao acampar, Jorge prepara comida enquanto o protagonista cuida da fogueira.

personagem_estrangeiro: “Dois... mesmo tempo?”

jorge: "Ele quer saber se dá pra dois programas rodarem ao mesmo tempo."

tablet: "Depende da arquitetura. Se houver mais de um processador, sim."

"Mas em um processador só, parece que é ao mesmo tempo, porque o sistema revezando muito rápido entre eles."

jorge: "Tipo quando eu fico cortando legumes e olho o fogo toda hora?"

tablet: "Sim. É o famoso tempo compartilhado. Um pouco pra cada processo."

personagem_estrangeiro: "Tempo… revezamento. Entendi."

