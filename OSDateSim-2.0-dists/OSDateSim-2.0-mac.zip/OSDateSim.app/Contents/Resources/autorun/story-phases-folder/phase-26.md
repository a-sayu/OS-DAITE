# Fase 26

## Como o sistema operacional lida com interrupções, o que é rotina de tratamento de interrupção

Fase 26 – Tratamento de interrupções

tablet: "A estrada está bloqueada por escombros."

"Ok, como a CPU do grupo, é hora de chamar a rotina de tratamento."

jorge: "Rotina do quê?"

"Tratar essa interrupção. Descer, analisar, liberar a estrada."

tablet: "Ativando protocolo: 'empurrar_coisas_2025'."
