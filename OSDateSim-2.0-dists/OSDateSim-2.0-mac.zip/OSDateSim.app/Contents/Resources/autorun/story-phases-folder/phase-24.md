# Fase 24

## Como indicar no código fonte uma chamada de sistema para usar um periférico qualquer
