# Fase 24

## Como indicar no código fonte uma chamada de sistema para usar um periférico qualquer

Fase 24 – Como indicar uma chamada de sistema no código

"Se fosse um código, seria algo como system_call(‘ligar_radio’)."

jorge: "Então se eu falar system_call(comida), você me dá?"

tablet: "Negado. Isso precisa de permissão de root. O root é o protagonista."

"Eu amo ser o root."
