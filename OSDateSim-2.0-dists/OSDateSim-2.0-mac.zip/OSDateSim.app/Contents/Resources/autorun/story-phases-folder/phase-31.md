# Fase 31

## Programas executando ao mesmo tempo
