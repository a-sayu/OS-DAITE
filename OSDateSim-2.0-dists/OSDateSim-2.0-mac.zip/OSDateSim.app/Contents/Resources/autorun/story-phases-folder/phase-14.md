# Fase 14

## Quem o sistema também particiona e como ele particiona?

computer "Como a gente tem tempo, quer particionar a mochila também?"

"Como assim? Achei que só a RAM fosse particionada assim..."

computer "Claro que não."

computer "A mochila também deve ficar organizada."

1 - Ah, sim, no SO o núcleo organiza em setor

2 - Ah, sim, no SO o núcleo organiza em blocos # vdd

Caso 1:

computer "Não exatamente, não podemos confundir setor com bloco."

computer "Setor é um termo mais de hardware, e é o menor tamanho de uma unidade de armazenamento."

"Ah... minha mochila tem espaços grandes demais pra serem chamados de setores, né?"

Caso 2:

"Cada compartimento e separação são blocos, certo?"

computer "Isso, pois facilitam a transferência de dados entre o sistema operacional e a memória secundária."

"E blocos são vários setores, seria como se cada setor fosse uma parte do compartimento."

"Todos do mesmo tamanho e que juntos formam o compartimento."

Enquanto vocês conversavam sobre esses assuntos, você termina de arrumar sua mochila.
