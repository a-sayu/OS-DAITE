# Fase 11

## Como organizar o armazenamento na memória RAM?

"É... Aqui começa a complicar. Bem, vamos aproveitar que a gente está na seção de moda da loja."

computer "Bem, analisando o ambiente..."

O tablet fica por alguns segundos carregando.

computer "Posso te ajudar, mas você precisa me dizer: como pretende organizar tudo?"

"Não cheguei a pensar tão longe... Então..."

computer "Que tal eu dou ideias de armazenamentos e você diz o que acha?"

Na tela do tablet aparecem três imagens com opções de armazenamento:

1 - Bolsos da roupa, similar ao cache, perto do processador.

2 - Bolsas com compartimentos, similar à uma RAM com particionamento

3 - Mochila, manter na memória secundária.

Caso 1:

computer "É uma escolha simples, não iria ser necessário ficar procurando, e vai estar tudo facilmente equipado."

"Mas não daria para armazenar muita coisa..."

computer "Acho que é melhor outra ideia então."

Caso 2:

computer "Bem, isso é organizado, com compartimentos você vai poder separar cada necessidade."

"Bem, esse era o plano inicial mesmo, além de ficar mais fácil de acessar."

computer "Então está decidido!"

Caso 3:

computer "No fim, você desistiu então?"

"Como assim?"

computer "Bem, só voltamos ao começo... E não resolve muita coisa."

"É, se for manter assim, eu ainda vou gastar muito tempo com a mochila."

computer "Acho que é melhor outra ideia então."
