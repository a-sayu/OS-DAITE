# Fase 13

## Quando a memória RAM deve ser particionada?

Por alguns minutos era buscado a bolsa, deixando o tablet sobre o banco que antes estava.

'Não é como se fosse roubar ele nessas ruas vazias'

Encontrando uma bolsa parecida com o conceito que o tablet havia mostrado.

Você chega até ele mostrando a bolsa.

"Achei! Aqui olha, exatamente igual."

computer "Que bom!"

"Eu decido como vai ser o tamanho de toda as partições agora?"

computer "Não, isso é algo que um particionamento fixo faria."

"Sim, mas seria durante as atividades do Sistema Operacional para mim."

1 - Ou seja, quando eu tiver os itens em mãos e eu precisar guardá-los. # vdd

2 - Ou seja, Agora. Eu só preciso tirar os itens da mochila agora, e começar a particionar já planejando o que vem.

3 - Não entendi...

Caso 1:

computer "Exatamente, conforme você tem programas a sua disposição."

computer "Você adiciona partições para cada programa."

Caso 2:

computer "Não... Isso é particionamento fixo."

computer "Agora seria o início das atividades do sistema operacional."

"Ah, sim, eu basicamente acabei de iniciar o processo de gerência da memória."

Caso 3:

computer "Recapitulando, se os itens forem como programas."

computer "A bolsa a memória RAM, cada compartimento uma partição variável."

computer "Colocar os programas na memória RAM é como colocar itens na bolsa separados por compartimento, certo?"

computer "Mas para isso você tem que ter os compartimentos montados."

computer "Você tem que fazer isso em algum momento, quando?"

"Ah faz sentido."
