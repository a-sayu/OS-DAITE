# Fase 25

## O que é uma interrupção, dê exemplo

Fase 25 – O que é uma interrupção (com exemplo)

De repente, um alarme soa alto. O carro para.

tablet: "Interrupção! Algo externo interrompeu o fluxo normal do processo!"

jorge: "O que foi isso?!"

"Talvez um bloqueio na estrada. Temos que tratar isso."

tablet: "Iniciando rotina de tratamento de interrupção..."

jorge: "Você é assustadoramente eficiente."
