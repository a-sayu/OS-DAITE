# Fase 25

## O que é uma interrupção, dê exemplo
