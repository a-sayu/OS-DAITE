# Fase 28

## O que é um Driver?

Fase 28 – O que é um Driver?

"Então você precisa de um driver... como um tradutor entre o hardware e o SO?"

tablet: "Exatamente. Drivers permitem que o sistema entenda e se comunique com dispositivos."

jorge: "Então... esse cara é tipo um hardware sem driver instalado?"

tablet: "Por enquanto, sim. Vou buscar um pacote de linguagem..."
