# Fase 21

## O problema de processos serem responsáveis pelo controle de recursos
