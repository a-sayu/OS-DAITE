# Fase 33

## O que faz a MMU
