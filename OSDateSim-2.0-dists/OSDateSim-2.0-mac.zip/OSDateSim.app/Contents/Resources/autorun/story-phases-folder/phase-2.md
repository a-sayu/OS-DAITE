# Fase 2

## **Tema:** As atividades que ocorrem no computador, o responsável e onde ele fica

ALERTA! ALERTA! ALERTA!

O som te assusta, seu corpo ainda está lento, por causa do cansaço do dia anterior, observando os seus arredores, você estranha, mas relembra dos eventos dos últimos meses, e como o mundo que você conhecia se foi, indo em direção ao computador, você se senta em frente a ele.

"O que você quer?"
Você pergunta, colocando a mão sobre a sua testa.

"O que um computador iria querer também né? Haha, parece que eu estou enlouquecendo..."

Você suspira e olha para as letras escritas no computador, avisando a falta de um teclado e também um alerta de emergência mundial sobre um assunto que você já estava bem familiarizado.

"Para que avisar sobre o eminente fim do mundo, se ele já aconteceu?"
Você conecta o teclado de fio próximo no computador e reinicia ele, e rapidamente ele liga. Carregando uma tela escrita D.AI.TE, com um simbolo similar a uma flor que rodava enquanto carrega o sistema.

Assim que o computador carrega, uma animação de uma linha surgindo e dois círculos aparecia, assemelhando-se a uma cara sorrindo.

C "Olá! Bem-Vindo ao computador oficial da DAITE, Development of Artificial Intelligence Technologies Enterprise, como um computador de auxílio adoraria que me desse um nome para sermos mais amigos! Como deseja me chamar?"

Você digita "Comp" na caixa de entrada de texto.

C "Comp! Esse mesmo?"

Você clica no botão que confirma a sua escolha. Logo depois ele pede o seu nome, digitando "SeuNome." na caixa de entrada de texto.

C "Certo, já que nos introduzimos SeuNome, por que você não me atendeu quando eu acordei!? Eu fiquei esperando por cerca de uma hora!"

"Como eu falo sobre isso com uma máquina... Você entende se eu falar que eu precisava acordar, levantar com calma, checar o que está ao meu refor, o que está acontecendo para então fazer as tarefas do dia?"

C "Desculpe, mas minhas bases de conhecimento humana são faltosas por conta da última atualização."

1- Assim que liga o computador, você não já inicia realizando processos complicados, é necessário que um programa armazenado na memória ROM da sua placa-mãe, chamado BIOS, confira sua memória RAM, a presença de teclado, e outros dispositivos ligados à você, lendo o seu armazenamento para então carregar o sistema operacional do local lido.

2- Você liga e tem que fazer as coisas de computador né, leds, tela e tals, pra que as coisas funcionem.

3- Eu não sei, como eu poderia entender uma máquina?

Caso 1: Comp "Oh! Então você ainda está verificando as suas partes e o que esta conectado a você? No caso "Lugar.", "Corpo." e "Memória.""

"Algo assim!"

Caso 2: Comp "Então você demora porque ainda não está mostrando o que está acontecendo?"

"Acho que não é isso que eu quero dizer, eu não mostro coisas, eu preciso sentir coisas e entender o meu arredor..." Sem muito o que fazer, para conversar com a máquina você vasculha as pilhas de papel que pareciam estar estranhamente muito relacionadas com um estudo de sistemas operacionais.

Caso 3: Comp "E como eu poderia entender você?" A máquina pergunta. Sem muito o que fazer, para que ela te entenda, você vasculha as pilhas de papel que pareciam estar estranhamente muito relacionadas com um estudo de sistemas operacionais.

Você olha pela janela, vendo as nuvens escuras que cobriam a cidade começarem a deixar cair gotas de chuva, parece que se não quiser ficar doente, buscar ajuda ou comida vai demorar um pouco.
