# Fase 16

## Como definir para onde ele deve alternar?

"Precisamos no entanto conversar sobre uma coisa agora."

Você retira o tablet da bolsa, retirando ele do silencioso.

"Esse é {computer}"

jorge "Hmm...? Isso é um tablet com um fundo animado nâo?"

"Não, esse é o {computer}, ele é um tablet com o sistema DAITE."

"Basicamente ele tem o mesmo sistema de IA que os robôs."

jorge "Por que você carrega isso com você?"

jorge "Equipamentos da DAITE são tipo imãs de robôs, ele é perigoso."

"Mas ele me ajudou até agora, e gostaria que você confiasse nele."

jorge "Complicado..."

jorge "Eu vou aceitar por enquanto, se alguma coisa acontecer por causa dele, eu to fora."

computer "Obrigado pelo voto de confiança, como posso te chamar?"

jorge "Não vou dar informações pessoais pra vocês IAs."

computer "Seu nome é muito comprido, Não vou dar informações pra vocês IAs."

computer "Posso te chamar de Não vou dar?"

TODO: set {jorge} = "Não vou dar."

Jorge apenas não responde, apenas olha para você com um olhar de julgamento.

"Ele apenas está sendo engraçado... Certo {computer}?"

computer "Como você não respondeu, irei assumir que seja esse seu nome."

computer "Caso queira mudar {jorge} você pode pedir para {player} mudar nas configurações."

"Okay..."

"Mas, okay, vamos para o outro tópico que eu tenho pra falar."

jorge "Vai me dizer que você tem outro amigo."

Jorge diz, fazendo sinal de aspas quando fala amigo.

"Não!"

"Só, ah..."

"O que eu quero dizer, é que como nós vamos escalonar as atividades."

jorge "Escalonar?"

"Sim, com escalonar eu quero dizer agendar cada tarefa que iremos fazer."

computer "Nesse caso, você quer saber a ordem que cada ação vai ter."

jorge "Ah faz sentido... Eu acho?"

No entanto você olha para a cara e percebe que ele não entendeu

'Será que eu conversei tanto com o {computer} que eu esqueci como conversar com pessoas normais?'

"Uh..."

'Sabendo de tudo que eu sei sobre prioridade e processos'

'Como eu explicaria sobre como definir quando alternar entre tarefas para uma pessoa normal...'

1 - O que eu queria dizer é que podemos usar um algoritmo Round Robin para definir para quem alternar...

2 - O que eu queria dizer é que a gente precisaria definir uma forma de agendar de forma prioritária, com prioridade nas tarefas e pessoas.

3 - O que eu queria dizer é que podemos usar um algoritmo Filas Múltiplas para definir para quem alternar...

Caso 1:

jorge "Oi?"

computer "Esse algoritmo não implementa prioridade."

jorge "E eu não faço ideia do que você está falando."

computer "O escalonamento round robin é quando se tem uma fila, e cada processo tem acesso à um quantum do processador."

"Basicamente a gente faz uma sequencia de tarefas e a gente vai separando algo como 5 minutos para cada, e vai revezando entre elas."

"Resultando em um ciclo."

jorge "Ah sim, realmente isso não tem prioridade nenhuma."

Casp 2:

jorge "Ah... Sim."

jorge "Mas isso é só o geral né? Qual o plano?"

2.1 - Então... Filas Múltiplas...?

2.2 - Então... Round Robin...?

Caso 2.1:

jorge "Oi?"

jorge "E eu não faço ideia do que você está falando."

computer "O escalonamento filas múltiplas tem várias filas separadas por prioridades, em que as tarefas são executadas em uma sequencia descendente de prioridades."

"O que eu quis dizer foi executarmos as tarefas mais importantes por completo e ir gradualmente alocando tempo para atividades de menor prioridade."

jorge "Ah sim... Isso parece interessante!"

Caso 2.2:

jorge "Oi?"

jorge "E eu não faço ideia do que você está falando."

computer "O escalonamento round robin é quando se tem uma fila, e cada processo tem acesso à um quantum do processador."

"Basicamente a gente faz uma sequencia de tarefas e a gente vai separando algo como 5 minutos para cada, e vai revezando entre elas."

"Resultando em um ciclo."

jorge "Mas isso... Não é prioritária?"

Caso 3:

jorge "Oi?"

computer "Esse algoritmo implementa prioridade, mas acho que nosso amigo {jorge} não entendeu..."

"Ah sim..."

jorge "Sim, eu não faço ideia do que vocês estão falando."

computer "O escalonamento filas múltiplas tem várias filas separadas por prioridades, em que as tarefas são executadas em uma sequencia descendente de prioridades."

"O que eu quis dizer foi executarmos as tarefas mais importantes por completo e ir gradualmente alocando tempo para atividades de menor prioridade."

jorge "Ah sim, faz sentido fazer algo assim."
