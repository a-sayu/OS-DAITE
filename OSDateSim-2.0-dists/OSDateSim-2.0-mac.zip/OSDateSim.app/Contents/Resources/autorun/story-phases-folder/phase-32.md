# Fase 32

## Modo Nucleo vs Modo Usuário
