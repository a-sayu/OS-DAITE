# História

## Cenário

Mundo Pós Apocaliptico, em que humanos foram dizimados por máquinas.
(*Abi: Lembrar de colocar um aviso de que a história é fictícia*)

## Personagens

Computador
Nome: Escolhível

Protagonista
Nome: Escolhível

## Fase 1 : Implementada, mas merece reboot

Computador: Beep Beep Beep Beep (* Um bípe contínuo toca)

Você sente seu estômago revirar com o último almoço que teve.

Você apenas quer dormir mais um pouco.

Computador: Beep Beep Beep Beep (* Um bípe contínuo toca)

Você se levanta, se deparando com um computador antigo apitando que estava no canto do quarto.

Opção:

1. Ler o aviso na tela.
Você vê diversos e-mails relacionados à empresa D.AI.TE;
+1 ponto de Interesse

2. Forçadamente desligar o computador.
Você remove o PC da tomada;
-2 pontos de Interesse

3. Proceder sem ler.
Você fecha o Pop up;
+1 ponto de Interesse

Caso 1:
    Lendo os e-mails, você encontra o vê um e-mail vermelho de alerta, em que é um alerta de que o mundo foi dominado por Inteligências Artificiais mortíferas e que foi possível através dos esforços de diversos cientistas da computação a correção do código globalmente. Assim como as mais de 90% de baixas humanas, e que está ocorrendo a busca por sobreviventes em cada continente, pedindo que busquem os pontos de socorro em posições estratégicas.

Caso 2:
    Você dorme por mais um dia.

Caso 3:
    Nada demais acontece.

A tela rapidamente pisca e um circulo branco começa a carregar na tela preta, um som sai e o computador ganhava dois olhos e uma boca simples.

Computador: Olá! Eu sou seu computador pessoal, como deseja me chamar?

(Opção de Inserir nome)

Você relutantemente dá um nome para o computador, digitando-o.

Computador: (nome) é um bom nome! Prazer em te conhecer, estou equipado com a versão de Inteligência Artificial 8010.256.a2 entretanto não possuo acesso à nenhum conhecimento além das bases mínimas de observação, devido ao grande colapso da huma-

Você: Tá bom tá bom, o que você quer pra me acordar do nada assim?

Você diz, se sentindo incomodado com lembranças não agradáveis.

Computador: Acordar? Não compreendo o que quer dizer, minhas bases de observação estão defeituosas, poderia me dizer o que isso significa?

Você: "Eu devo realmente explicar isso para uma máquina?"

Você: "Bem, não custa nada..."

1. Acordar é como quando um computador precisa ser ligado para iniciar suas operações. Um computador carrega seu sistema operacional da memória secundária assim como uma pessoa acorda verificando seu funcionamento e ações do dia.

2. Acordar é levantar da cama depois de uma longa noite de sono. Você dorme por um tempo, descansa e lida com mais um dia.

3. Acordar é lidar com um dia horrível como esse. Existiria realmente algum tipo de associação que você entenderia?

Caso 2: Caso 3:
    O computador não entendeu o que você quis dizer, novamente ele pergunta.
    -1 de Interesse

Caso 1:
    O computador mostra um rosto semelhante ao emoji: 😯

Computador: Certo, vou inserir em minhas bases de observação esse conhecimento.

Você: Tá, mas porque você me acordou?

Computador: Como novo usuário de (nome) preciso alertar sobre a sua segurança. A empresa D.AI.TE precisa que seus funcionários estejam em segurança junto de seus familiares.

Computador: O ponto mais próximo de refugiados é em 15 km, usando seu login e senha você conseguiria usar o carro da-

Você: Funcionário? Acho que voce está confundindo.

Você: Eu não tenho nada haver com essa empresa.

Computador: Ainda assim, usuário de (nome) precisa estar em segurança!

Computador: Apesar de não haver conexão à internet ainda posso acessar a rede interna da D.AI.TE, e certamente ainda há sobreviventes no campo de refugiados à 15 km, caso possua um celular posso fornecer um aplicativo com minhas capacidades reduzidas para fornecer acesso ao campo.

## Fase 2: Todas as Atividades que acontecem no computador, o responsável e onde ele fica

* Verifica o setup, faz o POST, descompacta dados, lê dispositivos de armazenamento e carrega o sistema operacional
* BIOS
* ROM

## Fase 3: As duas últimas tarefas executadas pela BIOS

## Fase 4: O que é Escalonamento

## Fase 5: Qual a relação entre Sistema Operacional e Escalonamento

## Fase 6: Classificação Multiprogramado

## Fase 7: O que é um processo?

## Fase 8: Qual a relação entre Sistema Operacional e Processos

## Fase 9: Qual a relação entre Sistema Operacional e Memória RAM

## Fase 10: Qual a importância do armazenamento do Sistema Operacional

## Fase 11: Método de organização na memória RAM

## Fase 12: Partições de Tamanhos Fixo, Partições de Tamanho Variável. Fragmentação Interna e Fragmentação Externa

## Fase 13: Quando a memória RAM deve ser particionada?

## Fase 14: QUem o sistema também particiona e como ele particiona?

## Fase 15: Como funciona um algotirmo de escalonamento e quanto tempo há para a realização de cada um dos trabalhos

## Fase 16: Como definir onde ele deve alterar?

## Fase 17 : O contexto, um conjunto de informações armazenados nos registradores a cada instante

## Fase 18 : --

## Fase 19 : --

## Fase 20 : --

## Fase 21 : --

## Fase 22 : --

## Fase 23 : --

## Fase 24 : --

## Fase 25 : --

## Fase 26 : --

## Fase 27 : --

## Fase 28 : --
